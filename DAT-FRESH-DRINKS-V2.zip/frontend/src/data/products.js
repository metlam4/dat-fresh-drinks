export const products=[
{id:'matcha-latte',name:'Matcha Latte',category:'Matcha',price:80000,description:'Smooth matcha with fresh milk.',featured:true},
{id:'cold-brew',name:'Cold Brew',category:'Coffee',price:65000,description:'Slow-steeped coffee, clean and refreshing.',featured:true},
{id:'peach-tea',name:'Peach Tea',category:'Tea',price:55000,description:'Fragrant tea with juicy peach.',featured:true},
{id:'strawberry-tea',name:'Strawberry Tea',category:'Tea',price:59000,description:'Fresh strawberry and bright tea.'},
{id:'americano',name:'Americano',category:'Coffee',price:45000,description:'Espresso with water, bold and simple.'},
{id:'latte',name:'Cafe Latte',category:'Coffee',price:60000,description:'Espresso balanced with silky milk.'},
{id:'mango-yogurt',name:'Mango Yogurt',category:'Yogurt',price:65000,description:'Creamy yogurt blended with mango.'},
{id:'berry-yogurt',name:'Berry Yogurt',category:'Yogurt',price:68000,description:'Yogurt with mixed berry flavor.'},
{id:'lemon-tea',name:'Lemon Tea',category:'Tea',price:49000,description:'Citrus tea for a refreshing finish.'},
{id:'chocolate',name:'Chocolate',category:'Chocolate',price:62000,description:'Rich chocolate with fresh milk.'}
];
