# ĐẤT FRESH DRINKS — Restored Project

This project was reconstructed from the surviving project history after the original local files were lost. Recovered architecture/route decisions were preserved; missing implementation was recreated so the repository is coherent.

## Stack
- Frontend: React + Vite + Tailwind CSS + React Router
- Backend: Node.js + Express + MongoDB/Mongoose
- Auth foundation: JWT + bcrypt

## Features restored
Customer: Home, Menu, Product Detail, Cart, Checkout, Login.
Admin: Dashboard, Products, Add Product, Orders, Customers.
Backend: products CRUD, order creation/status, register/login, MongoDB connection.
The original business scope also included dine-in, takeaway, delivery and a barista/staff workflow; the Order schema supports these statuses/service types for continued development.

## Run
### 1. MongoDB
Install/start MongoDB locally OR use MongoDB Atlas. Copy `backend/.env.example` to `backend/.env` and set `MONGO_URI`.

### 2. Backend
```bash
cd backend
npm install
npm run seed
npm run dev
```
API: http://localhost:5000/api

### 3. Frontend
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

## Important restoration note
The starter catalog and UI are safe reconstructed defaults where original assets/exact source text were not recoverable. Do not treat every line as byte-for-byte original code.
